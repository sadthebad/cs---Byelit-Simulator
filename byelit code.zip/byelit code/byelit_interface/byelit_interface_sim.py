import tkinter as tk
import random
import subprocess
import sys
import os
from tkinter import messagebox

class ByelitAmongUsInterface:
    def __init__(self, root):
        self.root = root
        self.root.title("BYELIT | VandyHacks Mission Control")
        
        # --- SETTING TO 720p ---
        self.width = 1280
        self.height = 720
        self.root.geometry(f"{self.width}x{self.height}")
        self.root.resizable(False, False)
        
        # --- AMONG US PALETTE ---
        self.clr_space = "#000000"
        self.clr_panel = "#C5D1D7"
        self.clr_btn = "#222222"
        self.clr_cyan = "#00FFFF"      # Task Cyan
        self.clr_yellow = "#FFFF00"    # Caution
        self.clr_red = "#FF0000"       # Emergency/Breach
        
        self.system_active = True

        # 1. THE SPACE CANVAS
        self.canvas = tk.Canvas(root, bg=self.clr_space, highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)

        # 2. ANIMATED STARS
        self.stars = []
        for _ in range(100):
            x, y = random.randint(0, self.width), random.randint(0, self.height)
            star = self.canvas.create_oval(x, y, x+2, y+2, fill="white", outline="")
            self.stars.append([star, random.uniform(1, 4)])

        self.draw_ui()
        self.animate_stars()

    def draw_ui(self):
        # Header
        self.canvas.create_text(640, 100, text="BYELIT ENTERPRISE", 
                                   font=("Arial Black", 42), fill="white")
        
        self.status_label = self.canvas.create_text(640, 160, text="SYSTEM STATUS: ONLINE", 
                                                       font=("Consolas", 16, "bold"), fill=self.clr_cyan)

        # Toggle Button (Power Override)
        self.create_toggle_btn(640, 240)

        # --- THE THREE MISSION NICHES ---
        
        # NICHE 1: Staff Operations
        self.create_task_button(320, 520, "STAFF OPERATIONS", self.clr_cyan, 
                                command=lambda: self.launch_module("coloredvest.py"))
        
        # NICHE 2: Cluster Detection (RE-CORRECTED FILENAME)
        self.create_task_button(640, 520, "CLUSTER DETECTION", self.clr_yellow, 
                                command=lambda: self.launch_module("cluster_detection.py"))
        
        # NICHE 3: Security Breach
        self.create_task_button(960, 520, "SECURITY BREACH", self.clr_red, 
                                command=lambda: self.launch_module("unauthorized_detect.py"))

    def create_toggle_btn(self, x, y):
        self.toggle_frame = tk.Frame(self.root, bg="#555555", padx=3, pady=3)
        self.btn_toggle = tk.Button(self.toggle_frame, text="POWER OVERRIDE", font=("Arial Black", 9),
                                    bg=self.clr_btn, fg=self.clr_cyan, relief="flat", 
                                    padx=15, pady=8, command=self.toggle_system)
        self.btn_toggle.pack()
        self.canvas.create_window(x, y, window=self.toggle_frame)

    def create_task_button(self, x, y, text, color, command):
        btn_frame = tk.Frame(self.root, bg=self.clr_panel, padx=4, pady=4)
        btn = tk.Button(btn_frame, text=text, font=("Arial Black", 10),
                        bg=self.clr_btn, fg=color, relief="flat", 
                        padx=30, pady=45, activebackground="#333333",
                        activeforeground="white", command=command)
        btn.pack()
        
        # Add a subtle hover effect
        btn.bind("<Enter>", lambda e: btn.config(fg="white"))
        btn.bind("<Leave>", lambda e: btn.config(fg=color))
        
        self.canvas.create_window(x, y, window=btn_frame)

    def launch_module(self, file_name):
        if not self.system_active:
            messagebox.showwarning("Power Failure", "Cannot launch module while System Status is OFFLINE.")
            return

        if os.path.exists(file_name):
            # Visual Feedback
            self.system_active = False 
            self.canvas.itemconfig(self.status_label, text=f"BOOTING {file_name.upper()}...", fill=self.clr_yellow)
            self.root.update()

            # Execute the specific script
            print(f"System: Dispatching {file_name}...")
            subprocess.Popen([sys.executable, file_name])

            # Resume UI after 4 seconds
            self.root.after(4000, self.resume_interface)
        else:
            messagebox.showerror("Module Error", f"Critical Error: '{file_name}' not found.")

    def resume_interface(self):
        self.system_active = True
        self.canvas.itemconfig(self.status_label, text="SYSTEM STATUS: ONLINE", fill=self.clr_cyan)
        self.animate_stars()

    def toggle_system(self):
        self.system_active = not self.system_active
        if self.system_active:
            self.canvas.itemconfig(self.status_label, text="SYSTEM STATUS: ONLINE", fill=self.clr_cyan)
            self.btn_toggle.config(fg=self.clr_cyan)
            self.animate_stars()
        else:
            self.canvas.itemconfig(self.status_label, text="SYSTEM STATUS: OFFLINE", fill=self.clr_red)
            self.btn_toggle.config(fg=self.clr_red)

    def animate_stars(self):
        if self.system_active:
            for star_data in self.stars:
                star, speed = star_data
                self.canvas.move(star, -speed, 0)
                pos = self.canvas.coords(star)
                if pos[2] < 0:
                    self.canvas.move(star, 1300, 0)
            self.root.after(30, self.animate_stars)

if __name__ == "__main__":
    root = tk.Tk()
    app = ByelitAmongUsInterface(root)
    root.mainloop()
from ultralytics import YOLO
import cv2
import numpy as np
from collections import deque
from deep_sort_realtime.deepsort_tracker import DeepSort
import os

class ClusterDetector:
    def __init__(self, model_path="yolov8n.pt"):
        # Use default embedder (no argument)
        self.tracker = DeepSort(max_age=30)
        self.model = YOLO(model_path)
        
        # UI Settings
        self.target_width = 1280
        self.target_height = 720
        
        # Tracking & Cluster Logic
        self.track_data = {}
        self.max_history = 30
        self.idle_threshold = 1.5    # Lowered for tighter security footage
        self.idle_frame_limit = 45   # ~1.5 seconds at 30fps
        self.proximity_ratio = 0.25  # Sensitivity for 'clustering' near doors
        
    def get_center(self, x1, y1, x2, y2):
        return ((x1 + x2) // 2, (y1 + y2) // 2)

    def get_distance(self, p1, p2):
        return ((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2)**0.5

    def calculate_movement(self, tid):
        centers = list(self.track_data[tid]['history_centers'])
        if len(centers) < 2: return 10.0 # Assume moving initially
        dist = self.get_distance(centers[0], centers[-1])
        return dist / len(centers)

    def run(self, source):
        cap = cv2.VideoCapture(source)
        
        # Check if video opened
        if not cap.isOpened():
            print(f"❌ ERROR: Cannot open video source: {source}")
            return

        # Setup Window for Interface Integration
        cv2.namedWindow("Byelit Mission Control", cv2.WINDOW_NORMAL)
        cv2.resizeWindow("Byelit Mission Control", self.target_width, self.target_height)

        print(f"🚀 Analyzing Security Feed for Clusters...")

        while cap.isOpened():
            ret, frame = cap.read()
            if not ret: break

            frame = cv2.resize(frame, (self.target_width, self.target_height))
            
            # YOLO Inference (imgsz 640 for speed)
            results = self.model(frame, verbose=False, imgsz=640)[0]

            detections = []
            for box in results.boxes:
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                label = self.model.names[int(box.cls[0])]
                conf = float(box.conf[0])
                if conf > 0.4 and label == 'person':
                    detections.append(([x1, y1, x2-x1, y2-y1], conf, label))

            # Update Tracker
            tracks = self.tracker.update_tracks(detections, frame=frame)
            active_idle_ids = []

            for track in tracks:
                if not track.is_confirmed() or track.time_since_update > 1:
                    continue

                tid = track.track_id
                if tid not in self.track_data:
                    self.track_data[tid] = {'history_centers': deque(maxlen=self.max_history), 'idle_frames': 0}

                l, t, r, b = map(int, track.to_tlbr())
                center = self.get_center(l, t, r, b)
                self.track_data[tid]['history_centers'].append(center)

                # Idle/Loitering Detection
                if self.calculate_movement(tid) < self.idle_threshold:
                    self.track_data[tid]['idle_frames'] += 1
                else:
                    self.track_data[tid]['idle_frames'] = 0

                # Color logic: Red if loitering, Green if moving
                color = (0, 255, 0)
                if self.track_data[tid]['idle_frames'] >= self.idle_frame_limit:
                    color = (0, 0, 255) # Red for Loitering Alert
                    active_idle_ids.append(tid)
                    cv2.putText(frame, "LOITERING ALERT", (l, t-25), 0, 0.7, (0, 0, 255), 2)

                cv2.rectangle(frame, (l, t), (r, b), color, 2)
                cv2.putText(frame, f"Subject {tid}", (l, t-10), 0, 0.6, color, 2)

            # Cluster/Accident Potential Logic
            cluster_count = 0
            for i in range(len(active_idle_ids)):
                for j in range(i + 1, len(active_idle_ids)):
                    id1, id2 = active_idle_ids[i], active_idle_ids[j]
                    c1, c2 = self.track_data[id1]['history_centers'][-1], self.track_data[id2]['history_centers'][-1]
                    
                    if self.get_distance(c1, c2) < (self.target_height * self.proximity_ratio):
                        cluster_count += 1
                        cv2.line(frame, c1, c2, (0, 165, 255), 3)
                        cv2.putText(frame, "ACCIDENT POTENTIAL", c1, 0, 0.6, (0, 165, 255), 2)

            # Dashboard Display
            cv2.rectangle(frame, (20, 20), (380, 120), (50, 50, 50), -1)
            cv2.putText(frame, f"SUBJECTS IN AREA: {len(tracks)}", (30, 55), 0, 0.7, (255, 255, 255), 2)
            cv2.putText(frame, f"IDLE/LOITERING: {len(active_idle_ids)}", (30, 85), 0, 0.7, (0, 255, 255), 2)
            cv2.putText(frame, f"HIGH-RISK CLUSTERS: {cluster_count}", (30, 115), 0, 0.7, (0, 165, 255), 2)

            cv2.imshow("Byelit Mission Control", frame)
            if cv2.waitKey(10) & 0xFF == ord('q'): break

        cap.release()
        cv2.destroyAllWindows()

if __name__ == "__main__":
    # Ensure this matches the file name you uploaded
    video_source = r"D:\Vandyhacks\sim_video\scenario3.mp4\37b129c2-ac33-4a50-8be5-97ec0e81115b.mp4" 
    
    detector = ClusterDetector()
    detector.run(video_source)
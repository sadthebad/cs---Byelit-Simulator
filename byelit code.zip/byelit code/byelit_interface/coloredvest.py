import cv2
import numpy as np
from ultralytics import YOLO
from datetime import datetime

model = YOLO('yolov8n.pt') 

# --- CORE TRACKING VARIABLES ---
ops_log = []
last_logged_status = ""
efficiency_score = 100.0 

def add_log(level, message):
    global last_logged_status
    if message != last_logged_status:
        timestamp = datetime.now().strftime("%H:%M:%S")
        entry = f"[{timestamp}] {level}: {message}"
        ops_log.insert(0, entry)
        last_logged_status = message
        if len(ops_log) > 6: ops_log.pop()

def identify_person(crop):
    """Refined detection for Red Hat, Blue Gloves, and Supervisor."""
    if crop.size == 0: return "Unknown"
    hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
    
    # 1. PRIORITY: ASSOCIATE MARKERS (Red Hat & Blue Gloves)
    # Red Hat (Check top of crop)
    mask_red1 = cv2.inRange(hsv, np.array([0, 120, 70]), np.array([10, 255, 255]))
    mask_red2 = cv2.inRange(hsv, np.array([170, 120, 70]), np.array([180, 255, 255]))
    # Blue Gloves (Check bottom of crop)
    mask_blue = cv2.inRange(hsv, np.array([100, 150, 50]), np.array([130, 255, 255]))

    if np.sum(mask_red1 + mask_red2) > 150 or np.sum(mask_blue) > 150: 
        return "Associate"

    # 2. SUPERVISOR (Tan Beanie & Grey Vest)
    mask_beanie = cv2.inRange(hsv, np.array([10, 20, 100]), np.array([25, 80, 255]))
    mask_grey_vest = cv2.inRange(hsv, np.array([0, 0, 30]), np.array([180, 40, 100]))
    
    if np.sum(mask_beanie) > 200 and np.sum(mask_grey_vest) > 500:
        return "Supervisor"
    
    return "Staff"

video_path = r"D:\Vandyhacks\sim_video\scenario1.mp4\4281403-uhd_3840_2160_25fps.mp4"
cap = cv2.VideoCapture(video_path)

while cap.isOpened():
    ret, frame = cap.read()
    if not ret: break

    frame = cv2.resize(frame, (1280, 720))
    results = model(frame, stream=True, verbose=False)
    
    people = []
    for r in results:
        for box in r.boxes:
            if int(box.cls[0]) == 0:
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                # Crop focusing on upper body and hands
                crop = frame[max(0, y1):min(720, y2), x1:x2]
                role = identify_person(crop)
                people.append({'box': (x1, y1, x2, y2), 'role': role})

    # --- EFFICIENCY ENGINE ---
    has_supervisor = any(p['role'] == "Supervisor" for p in people)
    associates = [p for p in people if p['role'] == "Associate"]
    
    is_procrastinating = False
    status_msg = "NORMAL OPERATIONS"

    # Detect if the Red Hat/Blue Glove duo is idling
    if len(associates) >= 2:
        dist = abs(associates[0]['box'][0] - associates[1]['box'][0])
        if dist < 220: # Proximity threshold for Photo 1
            if not has_supervisor:
                is_procrastinating = True
                status_msg = "PROCRASTINATION DETECTED"
                efficiency_score = max(0, efficiency_score - 0.2) # Active drop
                add_log("P2-WARN", "Associate Procrastination")
            else:
                status_msg = "SUPERVISED BRIEFING"
                efficiency_score = min(100, efficiency_score + 0.05) # Slow recovery
                add_log("P3-INFO", "Authorized Briefing")
    elif has_supervisor:
        add_log("INFO", "Supervisor Patrol Active")

    # --- UI RENDERING ---
    # HUD Top Bar
    hud_bg = (0, 0, 255) if is_procrastinating else (20, 20, 20)
    cv2.rectangle(frame, (0, 0), (1280, 65), hud_bg, -1)
    cv2.putText(frame, f"OPS: {status_msg}", (25, 45), 1, 2, (255, 255, 255), 2)
    cv2.putText(frame, f"EFFICIENCY: {int(efficiency_score)}%", (900, 45), 1, 2, (0, 255, 0), 2)

    # Activity Log Overlay
    overlay = frame.copy()
    cv2.rectangle(overlay, (15, 530), (460, 705), (0, 0, 0), -1)
    frame = cv2.addWeighted(overlay, 0.4, frame, 0.6, 0)
    cv2.putText(frame, "BYELIT ACTIVITY LOG", (25, 560), 1, 1.3, (255, 255, 255), 2)
    for i, log in enumerate(ops_log):
        col = (0, 165, 255) if "P2" in log else (255, 255, 255)
        cv2.putText(frame, log, (25, 590 + (i * 22)), 1, 0.9, col, 1)

    # Bounding Boxes and Labels
    for p in people:
        x1, y1, x2, y2 = p['box']
        if p['role'] == "Supervisor":
            color, tag = (255, 255, 255), "Supervisor (Active)"
        elif p['role'] == "Associate":
            color = (0, 255, 0) # Green for associates as requested
            tag = "Associate - Procrastination" if is_procrastinating else "Associate - Working"
        else:
            color, tag = (150, 150, 150), "Staff"

        cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
        cv2.putText(frame, tag, (x1, y1-12), 1, 1.2, color, 2)

    cv2.imshow('Byelit AI - Live Unified Feed', frame)
    if cv2.waitKey(1) & 0xFF == ord('q'): break

cap.release()
cv2.destroyAllWindows()
import cv2
import numpy as np
from ultralytics import YOLO
from datetime import datetime
import torch
from collections import deque
from deep_sort_realtime.deepsort_tracker import DeepSort

# --- INITIALIZATION ---
cv2.setUseOptimized(True)
device = 'cuda' if torch.cuda.is_available() else 'cpu'
model = YOLO('yolov8n.pt').to(device)
tracker = DeepSort(max_age=30) 

# --- SECURITY SETTINGS ---
RESTRICTED_LINE_X = 600      
WANDER_THRESHOLD_FRAMES = 60 
ops_log = []
threat_level = 0.0
track_timers = {}            

def add_log(level, message):
    timestamp = datetime.now().strftime("%H:%M:%S")
    entry = f"[{timestamp}] {level}: {message}"
    if not ops_log or message != ops_log[0].split(": ")[1]:
        ops_log.insert(0, entry)
        if len(ops_log) > 6: ops_log.pop()

# --- VIDEO SOURCE ---
video_path = r"D:\Vandyhacks\sim_video\scenario2.mp4\99eb5429-e7a1-492b-bc0b-b52d6963ba70.mp4" 
cap = cv2.VideoCapture(video_path)

while cap.isOpened():
    ret, frame = cap.read()
    if not ret: break

    frame = cv2.resize(frame, (1280, 720))
    results = model(frame, verbose=False, imgsz=320)[0]
    
    detections = []
    for box in results.boxes:
        if int(box.cls[0]) == 0: 
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            conf = float(box.conf[0])
            detections.append(([x1, y1, x2-x1, y2-y1], conf, 'person'))

    tracks = tracker.update_tracks(detections, frame=frame)
    
    status_msg = "SECURE: MONITORING"
    hud_color = (20, 20, 20) 
    active_breach = False

    # Draw the Restricted Boundary
    cv2.line(frame, (RESTRICTED_LINE_X, 0), (RESTRICTED_LINE_X, 720), (0, 0, 255), 2)
    cv2.putText(frame, "RESTRICTED ZONE", (RESTRICTED_LINE_X + 10, 30), 1, 1.2, (0, 0, 255), 2)

    for track in tracks:
        if not track.is_confirmed() or track.time_since_update > 1:
            continue
            
        tid = track.track_id
        l, t, r, b = map(int, track.to_tlbr())
        cx = (l + r) // 2
        
        # --- THE SUSPICION ENGINE ---
        if cx > RESTRICTED_LINE_X:
            track_timers[tid] = track_timers.get(tid, 0) + 1
            
            # Check if they have exceeded the wandering threshold
            if track_timers[tid] > WANDER_THRESHOLD_FRAMES:
                active_breach = True
                box_color = (0, 0, 255) # Red
                # UPDATED LABEL
                label = f"SUSPICIOUS: ID {tid}" 
                add_log("P1-CRITICAL", f"SUSPICIOUS ACTIVITY: ID {tid} loitering")
            else:
                box_color = (0, 165, 255) # Orange
                label = f"POTENTIAL SUSPECT: {tid}"
                # Add a visual "timer" so we can see the suspicion building
                timer_pct = int((track_timers[tid] / WANDER_THRESHOLD_FRAMES) * 100)
                cv2.putText(frame, f"ANALYZING: {timer_pct}%", (l, b + 20), 1, 1.0, (0, 165, 255), 1)
        else:
            track_timers[tid] = 0
            box_color = (0, 255, 0) # Green
            label = f"AUTHORIZED: {tid}"

        cv2.rectangle(frame, (l, t), (r, b), box_color, 2)
        cv2.putText(frame, label, (l, t-10), 1, 1.2, box_color, 2)

    # --- HUD ANIMATION ---
    if active_breach:
        threat_level = min(100, threat_level + 5.0)
        status_msg = "WARNING: SUSPICIOUS FIGURE DETECTED"
        hud_color = (0, 0, 180) 
    else:
        threat_level = max(0, threat_level - 1.0)

    # --- UI RENDERING ---
    cv2.rectangle(frame, (0, 0), (1280, 65), hud_color, -1)
    cv2.putText(frame, f"BYELIT SECURITY: {status_msg}", (25, 45), 1, 2, (255, 255, 255), 2)
    cv2.putText(frame, f"THREAT: {int(threat_level)}%", (950, 45), 1, 2, (255, 255, 255), 2)

    overlay = frame.copy()
    cv2.rectangle(overlay, (15, 530), (460, 705), (0, 0, 0), -1)
    frame = cv2.addWeighted(overlay, 0.4, frame, 0.6, 0)
    cv2.putText(frame, "SECURITY EVENT LOG", (25, 560), 1, 1.3, (255, 255, 255), 2)
    for i, log in enumerate(ops_log):
        log_col = (0, 0, 255) if "SUSPICIOUS" in log else (255, 255, 255)
        cv2.putText(frame, log, (25, 590 + (i * 22)), 1, 0.9, log_col, 1)

    cv2.imshow('Byelit Mission Control - Security Niche', frame)
    if cv2.waitKey(1) & 0xFF == ord('q'): break

cap.release()
cv2.destroyAllWindows()